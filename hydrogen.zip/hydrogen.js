function myMap()
{
  myCenter=new google.maps.LatLng(58.0104,56.2294, 58.0228,56.2294);
  let mapOptions= {
    center:myCenter,
    zoom:12, scrollwheel: false, draggable: false,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  let map=new google.maps.Map(document.getElementById("googleMap"),mapOptions);

  let marker = new google.maps.Marker({
    position: myCenter,
  });
  marker.setMap(map);
}

// Модель Галерея Изображений
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  let captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

// Изменить стиль навигационной панель при прокрутке
window.onscroll = function() {myFunction()};
function myFunction() {
    let navbar = document.getElementById("myNavbar");
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        navbar.className = "w3-bar" + " w3-card" + " w3-animate-top" + " w3-white";
    } else {
        navbar.className = navbar.className.replace(" w3-card w3-animate-top w3-white", "");
    }
}

// Переключение меню на маленьких экранах при нажатии на кнопку меню 
function toggleFunction() {
    let x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}





