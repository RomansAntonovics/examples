function initMap()
            {
                let element = document.getElementById('map');
                let options = {
                   zoom: 15, 
                   center: {lat: 51.92353751506625, lng: 4.473715065913668}
                   
                };

                let myMap = new google.maps.Map(element, options);

                let markers = [
                {
                    coordinates: {lat: 51.92353751506625, lng: 4.473715065913668},
                    image: '360_F_242239990_Ttfbp1Yww0rPtDxjsfYK2Dl4Qrh6wWRF.png',
                    info: '<h1>Developers</h1>'
                },
                {
                    coordinates: {lat: 52.55962560710856, lng: 4.602646636636214},
                    info: '<h1>Fuel</h1>'
                }

                ];

                for (let i = 0; i<markers.length; i++)
                {
                    addMarker(markers[i]);
                }

                addMarker();

                addMarker();
                 
                /*
                    let infoWindow = new google.maps.infoWindow({
                    content: '<h6>text</h6>'
                });

                

                marker.addListener('click', function(){
                    infoWindow.open(myMap, marker);

                });
                */
               function addMarker (properties){
                let marker = new google.maps.Marker({
                    position: properties.coordinates,
                    map: myMap,
                    
                });

                if(properties.image){
                    marker.setIcon(properties. image);
                }

                if(properties.info){
                    let InfoWindow = new google.maps.InfoWindow({
                    content: properties.info
                });

                

                marker.addListener('click', function(){
                    InfoWindow.open(myMap, marker);

                });
                }

               }
       }     